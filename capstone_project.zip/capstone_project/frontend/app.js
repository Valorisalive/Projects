const API = 'http://localhost:5000/api';

async function api(path, method='GET', body=null) {
  const opts = { method, headers: {} };
  if (body) { opts.headers['Content-Type']='application/json'; opts.body = JSON.stringify(body); }
  const res = await fetch(path, opts);
  if (res.headers.get('content-type')?.includes('application/json')) return res.json();
  return res;
}

async function loadTransactions(q='') {
  const res = await api(API+'/transactions');
  window.transactions = res;
  renderTable(res);
  updateCharts();
}

function renderTable(tx) {
  const tbody = document.querySelector('#txTable tbody');
  tbody.innerHTML='';
  tx.forEach(t=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${t.date}</td><td>${t.type}</td><td>${t.category||''}</td><td>${t.amount}</td><td>${t.note||''}</td>
    <td>
      <button onclick="editTx(${t.id})">Edit</button>
      <button onclick="deleteTx(${t.id})" style="background:#ef4444">Delete</button>
    </td>`;
    tbody.appendChild(tr);
  });
}

document.getElementById('addBtn').onclick = async ()=>{
  const amount = document.getElementById('amount').value;
  const type = document.getElementById('type').value;
  const category = document.getElementById('category').value;
  const note = document.getElementById('note').value;
  const date = document.getElementById('date').value || new Date().toISOString().slice(0,10);
  if (!amount) { alert('Enter amount'); return; }
  await api(API+'/transactions', 'POST', { amount, type, category, note, date });
  document.getElementById('amount').value=''; document.getElementById('note').value='';
  loadTransactions();
};

async function deleteTx(id) {
  if (!confirm('Delete transaction?')) return;
  await api(API+'/transactions/'+id, 'DELETE');
  loadTransactions();
}

window.editTx = async function(id) {
  const tx = window.transactions.find(t=>t.id===id);
  const newAmt = prompt('Amount', tx.amount);
  if (newAmt===null) return;
  const newNote = prompt('Note', tx.note||'') ?? '';
  await api(API+'/transactions/'+id, 'PUT', { ...tx, amount:newAmt, note:newNote });
  loadTransactions();
}

// Charts
let pieChart, trendChart;
function updateCharts() {
  const tx = window.transactions || [];
  const expenses = tx.filter(t=>t.type==='Expense');
  const categories = ['Food','Transport','Entertainment','Rent','Utilities','Other'];
  const totals = categories.map(c => expenses.filter(e=>e.category===c).reduce((s,x)=>s+x.amount,0));
  const pieData = { labels: categories, datasets: [{ data: totals, backgroundColor:['#0088FE','#00C49F','#FFBB28','#FF8042','#AA66CC','#FF4444'] }] };
  const ctx = document.getElementById('pie').getContext('2d');
  if (pieChart) pieChart.destroy();
  pieChart = new Chart(ctx, { type:'pie', data: pieData });

  // Trend: monthly income vs expense
  const byMonth = {};
  tx.forEach(t=>{
    const m = t.date.slice(0,7);
    if (!byMonth[m]) byMonth[m]={inc:0,exp:0};
    if (t.type==='Income') byMonth[m].inc += t.amount;
    else byMonth[m].exp += t.amount;
  });
  const months = Object.keys(byMonth).sort();
  const incData = months.map(m=>byMonth[m].inc);
  const expData = months.map(m=>byMonth[m].exp);
  const tctx = document.getElementById('trend').getContext('2d');
  if (trendChart) trendChart.destroy();
  trendChart = new Chart(tctx, { type:'line', data: { labels: months, datasets: [{ label:'Income', data:incData, fill:false }, { label:'Expense', data:expData, fill:false }] } });

  // Summary
  const totalInc = tx.filter(t=>t.type==='Income').reduce((s,x)=>s+x.amount,0);
  const totalExp = tx.filter(t=>t.type==='Expense').reduce((s,x)=>s+x.amount,0);
  const savings = totalInc - totalExp;
  document.getElementById('summary').innerHTML = `<strong>Total Income:</strong> ₹${totalInc.toFixed(2)} &nbsp; <strong>Total Expense:</strong> ₹${totalExp.toFixed(2)} &nbsp; <strong>Savings:</strong> ₹${savings.toFixed(2)}`;
  loadBudgets(document.getElementById('b_month').value);
}

// Budgets
document.getElementById('setBudgetBtn').onclick = async ()=>{
  const category = document.getElementById('b_category').value;
  const month = document.getElementById('b_month').value;
  const limit = document.getElementById('b_limit').value;
  if (!month || !limit) { alert('Select month and limit'); return; }
  await api(API+'/budgets', 'POST', { category, month, limit });
  loadBudgets(month);
};

async function loadBudgets(month=null) {
  const m = month || document.getElementById('b_month').value || new Date().toISOString().slice(0,7);
  const res = await api(API+'/budgets?month='+m);
  const div = document.getElementById('budgetsList');
  div.innerHTML='';
  const categories = ['Food','Transport','Entertainment','Rent','Utilities','Other'];
  const tx = window.transactions || [];
  categories.forEach(cat=>{
    const budget = res.find(b=>b.category===cat)?.limit || 0;
    const spent = tx.filter(t=>t.type==='Expense' && t.category===cat && t.date.startsWith(m)).reduce((s,x)=>s+x.amount,0);
    const pct = budget>0 ? Math.min(100, Math.round((spent/budget)*100)) : 0;
    const item = document.createElement('div');
    item.innerHTML = `<strong>${cat}</strong>: ₹${spent.toFixed(2)} / ₹${budget} <div class="progress"><span style="width:${pct}%"></span></div>`;
    div.appendChild(item);
    if (budget>0 && spent>budget) {
      const alert = document.createElement('div'); alert.style.color='red'; alert.textContent = `${cat} overspent by ₹${(spent-budget).toFixed(2)}`;
      div.appendChild(alert);
    }
  });
}

// Export CSV
document.getElementById('exportBtn').onclick = ()=>{
  window.open(API+'/export', '_blank');
}

// Refresh
document.getElementById('refreshBtn').onclick = loadTransactions;
window.onload = ()=>{ loadTransactions(); document.getElementById('b_month').value = new Date().toISOString().slice(0,7); }

// Simple group management
document.getElementById('g_create').onclick = async ()=>{
  const name = document.getElementById('g_name').value;
  if (!name) return alert('Enter name');
  const res = await api(API+'/groups','POST',{ name });
  document.getElementById('g_name').value='';
  loadGroups();
};

async function loadGroups() {
  const groups = await api(API+'/groups');
  const div = document.getElementById('groups'); div.innerHTML='';
  groups.forEach(g=>{
    const d = document.createElement('div');
    d.innerHTML = `<strong>${g.name}</strong> <button onclick="openGroup(${g.id}, '${g.name}')">Open</button>`;
    div.appendChild(d);
  });
}

window.openGroup = async function(id, name) {
  const members = await api(API+`/groups/${id}/members`);
  const area = document.getElementById('group_area'); area.innerHTML = `<h4>Group: ${name}</h4>`;
  const addMem = document.createElement('div');
  addMem.innerHTML = '<input id="mname" placeholder="Member name"/><button id="addmembtn">Add Member</button>';
  area.appendChild(addMem);
  document.getElementById('addmembtn').onclick = async ()=>{
    const nm = document.getElementById('mname').value;
    if (!nm) return;
    await api(API+`/groups/${id}/members`, 'POST', { name: nm });
    openGroup(id, name);
  };
  const list = document.createElement('div');
  list.innerHTML = '<h5>Members</h5>';
  members.forEach(m=>{ const p = document.createElement('div'); p.textContent = m.name; list.appendChild(p); });
  area.appendChild(list);

  // Simple UI: record a group expense and split equally
  const gexp = document.createElement('div');
  gexp.innerHTML = '<h5>Add Group Expense (equal split)</h5><input id="g_amount" placeholder="Amount"/><input id="g_cat" placeholder="Category"/><button id="g_add">Add</button>';
  area.appendChild(gexp);
  document.getElementById('g_add').onclick = async ()=>{
    const amt = parseFloat(document.getElementById('g_amount').value);
    const cat = document.getElementById('g_cat').value || 'Other';
    if (!amt) return alert('Enter amount');
    // create a transaction with group_id
    await api(API+'/transactions','POST',{ amount:amt, type:'Expense', category:cat, note:'Group:'+name, date:new Date().toISOString().slice(0,10), group_id:id });
    // compute split and show balances (simple)
    const txs = await api(API+'/transactions?');
    const groupTxs = txs.filter(t=>t.group_id===id);
    const members = await api(API+`/groups/${id}/members`);
    const per = amt / members.length;
    const balances = members.map(m => ({ name:m.name, owes: per }));
    const balDiv = document.createElement('div'); balDiv.innerHTML = '<h5>Current Split</h5>';
    balances.forEach(b=>{ const p=document.createElement('div'); p.textContent = `${b.name} owes ₹${b.owes.toFixed(2)}`; balDiv.appendChild(p); });
    area.appendChild(balDiv);
    loadTransactions();
  };

  // Settlements view
  const sdiv = document.createElement('div'); sdiv.innerHTML = '<h5>Settlements</h5><div id="settles"></div>';
  area.appendChild(sdiv);
  const settles = await api(API+`/groups/${id}/settlements`);
  const sd = document.getElementById('settles');
  sd.innerHTML = '';
  settles.forEach(s=>{ const p=document.createElement('div'); p.textContent = `${s.payer} paid ${s.payee} ₹${s.amount} on ${s.date}`; sd.appendChild(p); });

  // settlement record UI
  const settleForm = document.createElement('div');
  settleForm.innerHTML = '<h5>Record Settlement</h5><input id="s_payer" placeholder="Payer"/><input id="s_payee" placeholder="Payee"/><input id="s_amt" placeholder="Amount"/><button id="s_rec">Record</button>';
  area.appendChild(settleForm);
  document.getElementById('s_rec').onclick = async ()=>{
    const payer=document.getElementById('s_payer').value, payee=document.getElementById('s_payee').value, amt=parseFloat(document.getElementById('s_amt').value);
    if (!payer||!payee||!amt) return alert('fill all');
    await api(API+`/groups/${id}/settlements`, 'POST', { payer, payee, amount:amt });
    openGroup(id, name);
  };
};

loadGroups();
