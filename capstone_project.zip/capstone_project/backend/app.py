from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
from datetime import datetime
import csv
import io

DB = 'budget.db'

def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    # transactions: id, amount, type, category, note, date, group_id
    c.execute('''
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            amount REAL NOT NULL,
            type TEXT NOT NULL,
            category TEXT,
            note TEXT,
            date TEXT NOT NULL,
            group_id INTEGER
        )
    ''')
    # budgets: id, category, month (YYYY-MM), limit_amount
    c.execute('''
        CREATE TABLE IF NOT EXISTS budgets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            category TEXT NOT NULL,
            month TEXT NOT NULL,
            limit_amount REAL NOT NULL,
            UNIQUE(category, month)
        )
    ''')
    # groups: id, name
    c.execute('''
        CREATE TABLE IF NOT EXISTS groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL
        )
    ''')
    # group_members: id, group_id, name
    c.execute('''
        CREATE TABLE IF NOT EXISTS group_members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_id INTEGER NOT NULL,
            name TEXT NOT NULL
        )
    ''')
    # settlements: id, group_id, payer, payee, amount, date
    c.execute('''
        CREATE TABLE IF NOT EXISTS settlements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            group_id INTEGER NOT NULL,
            payer TEXT NOT NULL,
            payee TEXT NOT NULL,
            amount REAL NOT NULL,
            date TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

def run_query(query, args=(), one=False):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute(query, args)
    if query.strip().upper().startswith('SELECT'):
        rows = c.fetchall()
        cols = [d[0] for d in c.description]
        results = [dict(zip(cols, r)) for r in rows]
        conn.close()
        return results[0] if one and results else results
    else:
        conn.commit()
        lastrowid = c.lastrowid
        conn.close()
        return lastrowid

app = Flask(__name__)
CORS(app)

init_db()

#Transactions
@app.route('/api/transactions', methods=['GET', 'POST'])
def transactions():
    if request.method == 'POST':
        data = request.json
        amount = float(data.get('amount', 0))
        ttype = data.get('type', 'Expense')
        category = data.get('category')
        note = data.get('note', '')
        date = data.get('date') or datetime.utcnow().strftime('%Y-%m-%d')
        group_id = data.get('group_id')
        run_query('INSERT INTO transactions (amount, type, category, note, date, group_id) VALUES (?, ?, ?, ?, ?, ?)',
                  (amount, ttype, category, note, date, group_id))
        return jsonify({'status': 'ok'}), 201
    else:
        args = request.args
        qs = "SELECT * FROM transactions WHERE 1=1"
        params = []
        if args.get('type'):
            qs += " AND type=?"; params.append(args.get('type'))
        if args.get('category'):
            qs += " AND category=?"; params.append(args.get('category'))
        if args.get('start'):
            qs += " AND date>=?"; params.append(args.get('start'))
        if args.get('end'):
            qs += " AND date<=?"; params.append(args.get('end'))
        qs += " ORDER BY date DESC"
        results = run_query(qs, tuple(params))
        return jsonify(results)

@app.route('/api/transactions/<int:tid>', methods=['PUT', 'DELETE'])
def transaction_modify(tid):
    if request.method == 'PUT':
        data = request.json
        run_query('UPDATE transactions SET amount=?, type=?, category=?, note=?, date=?, group_id=? WHERE id=?',
                  (float(data.get('amount', 0)), data.get('type'), data.get('category'),
                   data.get('note'), data.get('date'), data.get('group_id'), tid))
        return jsonify({'status': 'ok'})
    else:
        run_query('DELETE FROM transactions WHERE id=?', (tid,))
        return jsonify({'status': 'deleted'})

#  Budgets 
@app.route('/api/budgets', methods=['GET', 'POST'])
def budgets():
    if request.method == 'POST':
        data = request.json
        category = data['category']
        month = data['month']
        limit = float(data['limit'])
        try:
            run_query('INSERT INTO budgets (category, month, limit_amount) VALUES (?, ?, ?)',
                      (category, month, limit))
        except Exception:
            run_query('UPDATE budgets SET limit_amount=? WHERE category=? AND month=?',
                      (limit, category, month))
        return jsonify({'status': 'ok'})
    else:
        month = request.args.get('month')
        if month:
            res = run_query('SELECT * FROM budgets WHERE month=?', (month,))
        else:
            res = run_query('SELECT * FROM budgets')
        return jsonify(res)

#  Groups 
@app.route('/api/groups', methods=['GET', 'POST'])
def groups():
    if request.method == 'POST':
        data = request.json
        name = data['name']
        gid = run_query('INSERT INTO groups (name) VALUES (?)', (name,))
        return jsonify({'id': gid, 'name': name})
    else:
        res = run_query('SELECT * FROM groups')
        return jsonify(res)

@app.route('/api/groups/<int:gid>/members', methods=['GET', 'POST'])
def group_members(gid):
    if request.method == 'POST':
        data = request.json
        name = data['name']
        mid = run_query('INSERT INTO group_members (group_id, name) VALUES (?, ?)', (gid, name))
        return jsonify({'id': mid, 'name': name})
    else:
        res = run_query('SELECT * FROM group_members WHERE group_id=?', (gid,))
        return jsonify(res)

# Settlements 
@app.route('/api/groups/<int:gid>/settlements', methods=['GET', 'POST'])
def settlements(gid):
    if request.method == 'POST':
        data = request.json
        payer = data['payer']
        payee = data['payee']
        amount = float(data['amount'])
        date = datetime.utcnow().strftime('%Y-%m-%d')
        sid = run_query('INSERT INTO settlements (group_id, payer, payee, amount, date) VALUES (?, ?, ?, ?, ?)',
                        (gid, payer, payee, amount, date))
        return jsonify({'id': sid})
    else:
        res = run_query('SELECT * FROM settlements WHERE group_id=?', (gid,))
        return jsonify(res)

#  Export 
@app.route('/api/export', methods=['GET'])
def export_csv():
    rows = run_query('SELECT * FROM transactions ORDER BY date DESC')
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow(['id', 'amount', 'type', 'category', 'note', 'date', 'group_id'])
    for r in rows:
        cw.writerow([r['id'], r['amount'], r['type'], r['category'],
                     r['note'], r['date'], r['group_id']])
    output = si.getvalue()
    return output, 200, {
        'Content-Type': 'text/csv',
        'Content-Disposition': 'attachment; filename=transactions.csv'
    }

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)
