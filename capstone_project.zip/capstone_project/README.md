# Personal Budget Tracker (Minimal Full-stack)

This is a minimal, functional Personal Budget Tracker according to the project specification.
It includes:
- Transactions CRUD (Flask + SQLite)
- Monthly budgets per category
- Dashboard with pie + trend charts (Chart.js)
- Export transactions CSV
- Simple group expense management with equal-split and settlements

Requirements:
- Python 3.8+
- pip install -r backend/requirements.txt
- Run backend: `python backend/app.py`
- Open `frontend/index.html` in your browser (or serve via a simple static server).
Notes:
- Backend runs on http://localhost:5000 by default.
- This is a scaffold to get you started; you can extend authentication, cloud sync, better UI, and more.

